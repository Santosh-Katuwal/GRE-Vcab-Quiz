import tkinter as tk
from tkinter import ttk
import csv
import random

filename='wordlists\\list3.csv'
class Quiz:
    def __init__(self, master):
        self.master = master
        self.questions = []
        self.correct_answers = []
        self.options = []
        self.user_answers = []
        self.score = 0
        self.correct_count = 0
        self.incorrect_count = 0
        self.incorrect_words = []
        self.load_questions()
        self.create_widgets()

    def load_questions(self):
        with open(filename, 'r') as file:
            reader = csv.reader(file)
            rows = list(reader)

            for row in rows:
                words = [word for word in row if word.strip() != '']
                if len(words) >= 2:
                    question_index = random.randint(1, len(words) - 1)
                    question = words[question_index]
                    self.questions.append(question)

                    correct_answer = words[0]
                    self.correct_answers.append(correct_answer)

                    options = random.sample([word for words in rows if words != row for word in words if word.strip() != '' and word != correct_answer], 4)
                    options.append(correct_answer)
                    random.shuffle(options)
                    self.options.append(options)

    def create_widgets(self):
        self.master.geometry("500x750")
        self.master.title("GRE Quiz By Santosh Katuwal")
        self.master.configure(bg="#f0f0f0")

        self.style = ttk.Style()
        self.style.configure("TFrame", background="#f0f0f0")
        self.style.configure("TLabel", font=("Arial", 12), background="#f0f0f0")
        self.style.configure("TButton", font=("Arial", 12))

        self.question_frame = ttk.Frame(self.master)
        self.question_frame.pack(pady=20)

        self.question_label = ttk.Label(self.question_frame, text="Question", foreground="#333333")
        self.question_label.pack()

        self.options_frame = ttk.Frame(self.master)
        self.options_frame.pack(pady=10)

        self.radio_var = tk.IntVar()

        self.radio_buttons = []
        for i in range(5):
            radio_button = ttk.Radiobutton(self.options_frame, variable=self.radio_var, value=i)
            radio_button.pack(pady=5)
            self.radio_buttons.append(radio_button)

        self.submit_button = ttk.Button(self.master, text="Submit", command=self.submit_answer)
        self.submit_button.pack(pady=20)

        self.correct_label = ttk.Label(self.master, text="Correct: 0", foreground="#009900")
        self.correct_label.pack(pady=5)

        self.incorrect_label = ttk.Label(self.master, text="Incorrect: 0", foreground="#FF0000")
        self.incorrect_label.pack(pady=5)

        self.incorrect_words_label = ttk.Label(self.master, text="Incorrect Words:", foreground="#333333")
        self.incorrect_words_label.pack()

        self.incorrect_words_text = tk.Text(self.master, height=5, width=30)
        self.incorrect_words_text.pack(pady=5)

        self.export_button = ttk.Button(self.master, text="Export Incorrect Words", command=self.export_incorrect_words)
        self.export_button.pack(pady=10)

        self.display_question()

    def display_question(self):
        if self.score > 0:
            self.correct_label.configure(text=f"Correct: {self.correct_count}")
            self.incorrect_label.configure(text=f"Incorrect: {self.incorrect_count}")

        if self.score >= len(self.questions):
            self.show_results()
            return

        question = self.questions[self.score]
        options = self.options[self.score]

        self.question_label.config(text=question)

        for i in range(5):
            radio_button = self.radio_buttons[i]
            radio_button.configure(text=options[i])
            radio_button.configure(state=tk.NORMAL)

        self.submit_button.configure(state=tk.NORMAL)

    def submit_answer(self):
        user_answer = self.radio_var.get()

        selected_option = self.radio_buttons[user_answer].cget('text')
        if selected_option == self.correct_answers[self.score]:
            self.score += 1
            self.correct_count += 1
        else:
            self.incorrect_count += 1
            self.incorrect_words.append(selected_option)

        for radio_button in self.radio_buttons:
            radio_button.configure(state=tk.DISABLED)

        self.submit_button.configure(state=tk.DISABLED)

        self.update_incorrect_words()

        self.master.after(1500, self.next_question)

    def update_incorrect_words(self):
        incorrect_words = "\n".join(self.incorrect_words)
        self.incorrect_words_text.delete(1.0, tk.END)
        self.incorrect_words_text.insert(tk.END, incorrect_words)

    def next_question(self):
        self.score += 1
        self.display_question()

    def show_results(self):
        self.question_label.config(text="Quiz Completed!")
        self.submit_button.configure(state=tk.DISABLED)

    def export_incorrect_words(self):
        filename = "incorrect_words.txt"
        with open(filename, "w") as file:
            file.write("\n".join(self.incorrect_words))
        tk.messagebox.showinfo("Export", f"Incorrect words exported to {filename}.")

if __name__ == '__main__':
    root = tk.Tk()
    quiz = Quiz(root)
    root.mainloop()
